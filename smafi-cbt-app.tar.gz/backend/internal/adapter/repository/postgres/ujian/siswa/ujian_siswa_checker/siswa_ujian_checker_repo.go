package siswaujiancheckerrepo

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"

	pg "github.com/mustafamadjid/web-app-cbt/internal/adapter/repository/postgres/contract"
	coreerror "github.com/mustafamadjid/web-app-cbt/internal/core/core_error"
	ujian "github.com/mustafamadjid/web-app-cbt/internal/core/domain/ujian_siswa"
	corelog "github.com/mustafamadjid/web-app-cbt/internal/core/port/out/log"
)

type SiswaUjianCheckerRepo struct {
	q      pg.Executor
	logger corelog.Logger
}

func NewSiswaUjianCheckerRepo(q pg.Executor, logger corelog.Logger) *SiswaUjianCheckerRepo {
	return &SiswaUjianCheckerRepo{q: q, logger: logger}
}

func (r *SiswaUjianCheckerRepo) loggerFor(ctx context.Context) corelog.Logger {
	return corelog.FromContextOr(ctx, r.logger)
}

func (r *SiswaUjianCheckerRepo) CheckValidSiswaInPesertaUjianById(ctx context.Context, idSiswa int, idJadwalUjian int) (bool, int, error) {
	const query = `
		SELECT
			pu.id_peserta_ujian
		FROM peserta_ujian pu
		WHERE pu.id_siswa = $1
			AND pu.id_jadwal_ujian = $2
		LIMIT 1
	`

	var idPesertaUjian int

	err := r.q.QueryRow(ctx, query, idSiswa, idJadwalUjian).Scan(&idPesertaUjian)
	if errors.Is(err, pgx.ErrNoRows) {
		return false, 0, nil
	}
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed checking siswa in peserta ujian", "layer", "repo.db", "op", "siswa_ujian.check_peserta", "err", err)
		return false, 0, err
	}

	return true, idPesertaUjian, nil
}

func (r *SiswaUjianCheckerRepo) CheckTokenUjian(ctx context.Context, token string, idJadwalUjian int) (bool, error) {
	const query = `
		SELECT EXISTS(
			SELECT 1
			FROM jadwal_ujian
			WHERE UPPER(token) = UPPER($1) AND id_jadwal_ujian = $2
		)
	`

	var exists bool
	if err := r.q.QueryRow(ctx, query, token, idJadwalUjian).Scan(&exists); err != nil {
		r.loggerFor(ctx).Error(ctx, "failed checking token ujian", "layer", "repo.db", "op", "siswa_ujian.check_token", "err", err)
		return false, err
	}

	return exists, nil
}

func (r *SiswaUjianCheckerRepo) CheckAttemptOwnershipBySiswa(ctx context.Context, idSiswa int, idAttempt ujian.ID) (bool, error) {
	const query = `
		SELECT EXISTS(
			SELECT 1
			FROM attempt_ujian au
			INNER JOIN peserta_ujian pu ON pu.id_peserta_ujian = au.id_peserta_ujian
			WHERE pu.id_siswa = $1
				AND au.id_attempt = $2
		)
	`

	var exists bool
	if err := r.q.QueryRow(ctx, query, idSiswa, idAttempt).Scan(&exists); err != nil {
		r.loggerFor(ctx).Error(ctx, "failed checking attempt ownership by siswa", "layer", "repo.db", "op", "siswa_ujian.check_attempt_ownership", "err", err)
		return false, err
	}

	return exists, nil
}

func (r *SiswaUjianCheckerRepo) GetDeadlineUjian(ctx context.Context, idJadwalUjian int) (time.Time, error) {
	const query = `
		SELECT waktu_selesai
		FROM jadwal_ujian
		WHERE id_jadwal_ujian = $1
	`

	var deadline time.Time
	err := r.q.QueryRow(ctx, query, idJadwalUjian).Scan(&deadline)
	if errors.Is(err, pgx.ErrNoRows) {
		return time.Time{}, coreerror.ErrNotFound
	}
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed get deadline ujian", "layer", "repo.db", "op", "siswa_ujian.get_deadline", "err", err)
		return time.Time{}, err
	}

	return deadline, nil
}
