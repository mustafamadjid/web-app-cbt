package userrepo

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	pg "github.com/mustafamadjid/web-app-cbt/internal/adapter/repository/postgres/contract"
	coreerror "github.com/mustafamadjid/web-app-cbt/internal/core/core_error"
	"github.com/mustafamadjid/web-app-cbt/internal/core/domain/user"
	corelog "github.com/mustafamadjid/web-app-cbt/internal/core/port/out/log"
	updatepatch "github.com/mustafamadjid/web-app-cbt/internal/core/port/out/update_patch"
)

type UserRepo struct {
	q      pg.Executor
	logger corelog.Logger
}

func NewUserRepo(q pg.Executor, logger corelog.Logger) *UserRepo {
	return &UserRepo{q: q, logger: logger}
}

func (r *UserRepo) loggerFor(ctx context.Context) corelog.Logger {
	return corelog.FromContextOr(ctx, r.logger)
}

func (r *UserRepo) FindUserByID(ctx context.Context, id user.ID) (user.Pengguna, error) {
	const query = `
		SELECT p.id_pengguna,
			p.username,
			p.email,
			p.password,
			p.nama_lengkap,
			p.jenis_kelamin,
			p.no_hp,
			r.nama_role,
			p.status_akun,
			p.foto
		FROM pengguna p
		JOIN role r ON p.id_role = r.id_role
		WHERE p.id_pengguna = $1
	`

	result, err := scanPenggunaRow(r.q.QueryRow(ctx, query, id))
	if errors.Is(err, pgx.ErrNoRows) {
		return user.Pengguna{}, coreerror.ErrNotFound
	}
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed finding user", "op", "user_repo.find_by_id", "user_id", id, "err", err)
		return user.Pengguna{}, err
	}

	return result, nil
}

func (r *UserRepo) UserExistByUsername(ctx context.Context, username string) (bool, error) {
	const query = `SELECT EXISTS (SELECT 1 FROM pengguna WHERE username = $1)`

	var exists bool
	if err := r.q.QueryRow(ctx, query, username).Scan(&exists); err != nil {
		r.loggerFor(ctx).Error(ctx, "failed checking username existence", "op", "user_repo.user_exists", "username", username, "err", err)
		return false, err
	}

	return exists, nil
}

func (r *UserRepo) CreateUser(ctx context.Context, pengguna user.Pengguna) (user.ID, error) {
	const query = `
		INSERT INTO pengguna (
			foto,
			nama_lengkap,
			jenis_kelamin,
			username,
			password,
			email,
			no_hp,
			id_role,
			status_akun
		)
		VALUES (
			$1,
			$2,
			$3,
			$4,
			$5,
			$6,
			$7,
			(SELECT id_role FROM role WHERE nama_role = $8),
			$9
		)
		RETURNING id_pengguna
	`

	jenisKelamin, err := parseJenisKelamin(pengguna.JenisKelamin)
	if err != nil {
		return 0, err
	}

	var id user.ID
	err = r.q.QueryRow(
		ctx,
		query,
		pengguna.Foto,
		pengguna.NamaLengkap,
		jenisKelamin,
		pengguna.Username,
		pengguna.PasswordHashed,
		userEmailPtrToDB(pengguna.Email),
		stringPtrToDB(pengguna.NoHp),
		string(pengguna.Role),
		string(pengguna.StatusAkun),
	).Scan(&id)
	if err != nil {
		if mappedErr := mapUserUniqueViolation(err); mappedErr != nil {
			return 0, mappedErr
		}

		r.loggerFor(ctx).Error(ctx, "failed creating user", "op", "user_repo.create", "err", err)
		return 0, err
	}

	return id, nil
}

func (r *UserRepo) UpdateUser(ctx context.Context, idPengguna user.ID, pengguna updatepatch.Pengguna) error {
	set := make([]string, 0, 8)
	args := make([]any, 0, 9)

	add := func(col string, v any) {
		args = append(args, v)
		set = append(set, fmt.Sprintf("%s=$%d", col, len(args)))
	}

	if pengguna.Username != nil {
		add("username", *pengguna.Username)
	}
	if pengguna.NamaLengkap != nil {
		add("nama_lengkap", *pengguna.NamaLengkap)
	}
	if pengguna.Email != nil {
		add("email", string(*pengguna.Email))
	}
	if pengguna.NoHp != nil {
		add("no_hp", *pengguna.NoHp)
	}
	if pengguna.Foto != nil {
		add("foto", *pengguna.Foto)
	}
	if pengguna.StatusAkun != nil {
		add("status_akun", string(*pengguna.StatusAkun))
	}
	if pengguna.Role != nil {
		args = append(args, string(*pengguna.Role))
		set = append(set, fmt.Sprintf("id_role=(SELECT id_role FROM role WHERE nama_role = $%d)", len(args)))
	}

	if pengguna.JenisKelamin != nil {
		jenisKelamin, err := parseJenisKelamin(*pengguna.JenisKelamin)
		if err != nil {
			return err
		}
		add("jenis_kelamin", jenisKelamin)
	}

	if len(set) == 0 {
		return nil
	}

	args = append(args, idPengguna)
	q := fmt.Sprintf(`UPDATE pengguna SET %s WHERE id_pengguna=$%d`, strings.Join(set, ", "), len(args))

	_, err := r.q.Exec(ctx, q, args...)
	if err != nil {
		if mappedErr := mapUserUniqueViolation(err); mappedErr != nil {
			return mappedErr
		}

		r.loggerFor(ctx).Error(ctx, "failed updating user", "op", "user_repo.update", "user_id", idPengguna, "err", err)
	}
	return err
}

func (r *UserRepo) DeleteUser(ctx context.Context, id user.ID) error {
	const query = `DELETE FROM pengguna WHERE id_pengguna = $1`

	result, err := r.q.Exec(ctx, query, id)
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed deleting user", "op", "user_repo.delete", "user_id", id, "err", err)
		return err
	}
	if result.RowsAffected() == 0 {
		return coreerror.ErrNotFound
	}

	return nil
}

func (r *UserRepo) DeleteUsers(ctx context.Context, ids []user.ID) (int64, error) {
	if len(ids) == 0 {
		return 0, coreerror.ErrNotFound
	}

	const query = `DELETE FROM pengguna WHERE id_pengguna = ANY($1)`

	result, err := r.q.Exec(ctx, query, ids)
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed deleting users", "op", "user_repo.delete_many", "err", err)
		return 0, err
	}
	if result.RowsAffected() == 0 {
		return 0, coreerror.ErrNotFound
	}

	return result.RowsAffected(), nil
}

func (r *UserRepo) ListUser(ctx context.Context) ([]user.Pengguna, error) {
	const query = `
		SELECT p.id_pengguna,
			p.username,
			p.email,
			p.password,
			p.nama_lengkap,
			p.jenis_kelamin,
			p.no_hp,
			r.nama_role,
			p.status_akun,
			p.foto
		FROM pengguna p
		JOIN role r ON p.id_role = r.id_role
		ORDER BY p.id_pengguna
	`

	rows, err := r.q.Query(ctx, query)
	if err != nil {
		r.loggerFor(ctx).Error(ctx, "failed listing users", "op", "user_repo.list", "err", err)
		return nil, err
	}
	defer rows.Close()

	return r.scanPenggunaRows(ctx, "user_repo.list", rows)
}

func parseJenisKelamin(value string) (int16, error) {
	normalized := strings.TrimSpace(strings.ToUpper(value))
	if normalized == "" {
		return 0, coreerror.ErrInvalidInput
	}

	if numeric, err := strconv.Atoi(normalized); err == nil {
		if numeric == 1 || numeric == 2 {
			return int16(numeric), nil
		}
	}

	switch normalized {
	case "L", "LK", "LAKI", "LAKI_LAKI", "LAKI-LAKI", "PRIA", "MALE":
		return 1, nil
	case "P", "PR", "PEREMPUAN", "WANITA", "FEMALE":
		return 2, nil
	default:
		return 0, coreerror.ErrInvalidInput
	}
}

func formatJenisKelamin(value int16) (string, error) {
	switch value {
	case 1:
		return "LAKI_LAKI", nil
	case 2:
		return "PEREMPUAN", nil
	default:
		return "", coreerror.ErrInvalidInput
	}
}

func mapUserUniqueViolation(err error) error {
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) || pgErr.Code != "23505" {
		return nil
	}

	switch pgErr.ConstraintName {
	case "uq_pengguna_username":
		return coreerror.ErrUsernameTaken
	case "uq_pengguna_email":
		return coreerror.ErrEmailTaken
	case "uq_pengguna_no_hp":
		return coreerror.ErrNoHpTaken
	default:
		return coreerror.ErrConflict
	}
}

func userEmailPtrToDB(email *user.Email) any {
	if email == nil {
		return nil
	}
	return string(*email)
}

func stringPtrToDB(value *string) any {
	if value == nil {
		return nil
	}
	return *value
}

func nullStringToPtr(value nullString) *string {
	if !value.Valid {
		return nil
	}
	v := value.String
	return &v
}

func nullStringToUserEmailPtr(value nullString) *user.Email {
	if !value.Valid {
		return nil
	}
	email := user.Email(value.String)
	return &email
}
