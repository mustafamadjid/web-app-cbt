package main

import (
	"fmt"

	"golang.org/x/crypto/bcrypt"
)

func createHashedPassword(password string) (string, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

func main() {
	hashedPassword, err := createHashedPassword("MYADMIN PW 123")
	if err != nil {
		panic(err)
	}
	fmt.Println(hashedPassword)
}