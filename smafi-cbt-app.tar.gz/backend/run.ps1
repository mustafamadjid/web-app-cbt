. ./export_env.ps1

cd cmd/http

go run .